package com.autonomouscar.sensor_management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SensorManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
