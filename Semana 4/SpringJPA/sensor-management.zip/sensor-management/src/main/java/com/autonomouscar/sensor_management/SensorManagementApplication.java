package com.autonomouscar.sensor_management;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SensorManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(SensorManagementApplication.class, args);
	}

}
