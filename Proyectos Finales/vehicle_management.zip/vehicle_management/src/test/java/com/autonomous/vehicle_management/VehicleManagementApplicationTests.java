package com.autonomous.vehicle_management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VehicleManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
