package com.bookstore.onlie_bookstore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlieBookstoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlieBookstoreApplication.class, args);
	}

}
